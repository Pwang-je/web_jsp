create FUNCTION func3 ( bno number )
	return VARCHAR2
IS
	bname varchar2(20);
BEGIN
    
  if bno is null then
    return '임시직';  
  else
    select buser_name into bname from buser where buser_no=bno;
    return bname;  
  end if;
end;
/

