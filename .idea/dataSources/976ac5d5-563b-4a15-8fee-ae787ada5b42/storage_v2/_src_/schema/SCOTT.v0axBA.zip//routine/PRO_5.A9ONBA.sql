create procedure pro_5
is
  cursor cur is 
              select id, name, weight
              from person;
  pid person.id%type;
  pid person.name%type;
  pid person.weight%type;
begin
  open cur;
  loop
    fetch cur into pid,pname,pweight;
    exit when cur%notfound; -- 루프 빠져나가기.
      dbms_output.put_line(pid || ' ' || pname || ' ' || pweight );
  end loop; 
  close cur;
end;
/

