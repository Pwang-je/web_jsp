create procedure p_d(no in jiktest.jikwon_no%type, jik jiktest.jikwon_jik%type)
is 
begin
  update jiktest set jikwon_jik=jik
          where jikwon_no=no;
end;
/

