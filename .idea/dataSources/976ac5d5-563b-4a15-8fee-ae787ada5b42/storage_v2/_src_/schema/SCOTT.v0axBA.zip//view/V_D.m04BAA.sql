create view V_D as
  SELECT	JIKWON_NAME,
				JIKWON_NO	*	10000
				AS	ypay
FROM		JIKWON
/

