create procedure p_b
is  bun number := 2;
begin
  update jiktest set jikwon_pay = jikwon_pay + 1000
  where jikwon_no = bun;
end;
/

