create view V_A as
  SELECT jikwon_no, 
       jikwon_name, 
       jikwon_pay 
FROM   vjikwon 
WHERE  jikwon_ibsail >= '2005-01-01'
/

